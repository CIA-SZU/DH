This program mainly implements the MOMFEA-SADE which was described in our paper:

Evolutionary Multi-tasking for Multi-objective Optimization with Subspace Alignment and Adaptive Differential Evolution

For any problem concerning the code, please feel free to contact DongHao (email: 1242618848@qq.com).