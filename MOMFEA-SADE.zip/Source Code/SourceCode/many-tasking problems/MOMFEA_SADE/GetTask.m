function[dim ,pop , Gfunction , F1Function , Hfunction , boundaryCvDv , Low , Upper] = GetTask( benchMark )
%GETTASK �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
switch benchMark
    case 1
        dim = 50;
        pop = 5000;
        Gfunction = 'Sphere';
        F1Function = 'linear';
        Hfunction = 'circle';
        boundaryCvDv = 1;
        Low = -100 .* ones(1 , 49);
        Upper = 100 .* ones(1 , 49);
        Low = [0 , Low];
        Upper = [1 , Upper];        
    case 2
        dim = 50;
        pop = 5000;
        Gfunction = 'Mean';
        F1Function = 'linear';
        Hfunction = 'concave';
        boundaryCvDv = 1;
        Low = -100 .* ones(1 , 49);
        Upper = 100 .* ones(1 , 49);
        Low = [0 , Low];
        Upper = [1 , Upper];
    case 3
        dim = 10;
        pop = 5000;
        Gfunction = 'Rosenbrock';
        F1Function = 'linear';
        Hfunction = 'concave';
        boundaryCvDv = 1;
        Low = -5 .* ones(1 , 9);
        Upper = 5 .* ones(1 , 9);
        Low = [0 , Low];
        Upper = [1 , Upper];
    case 4
                dim = 50;
        pop = 5000;
        Gfunction = 'Rastrigin';
        F1Function = 'linear';
        Hfunction = 'circle';
        boundaryCvDv = 1;
        Low = -2 .* ones(1 , 49);
        Upper = 2 .* ones(1 , 49);
        Low = [0 , Low];
        Upper = [1 , Upper]; 
    case 5
        dim = 50;
        pop = 5000;
        Gfunction = 'Ackley';
        F1Function = 'linear';
        Hfunction = 'convex';
        boundaryCvDv = 1;
        Low = -1 .* ones(1 , 49);
        Upper = 1 .* ones(1 , 49);
        Low = [0 , Low];
        Upper = [1 , Upper];
    case 6
        dim = 50;
        pop = 5000;
        Gfunction = 'Griewank';
        F1Function = 'linear';
        Hfunction = 'circle';
        boundaryCvDv = 1;
        Low = -50 .* ones(1 , 49);
        Upper = 50 .* ones(1 , 49);
        Low = [0 , Low];
        Upper = [1 , Upper];      
        
        
        
        
end
end

