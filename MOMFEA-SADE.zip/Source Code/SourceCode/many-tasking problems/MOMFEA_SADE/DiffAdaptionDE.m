%% DiffAdaptionDE: function description
%
function u1 = DiffAdaptionDE(parent , DE_num , population , generation)
% DE in different task
cr = randi([3,9],1);
cr = cr/10;
% F=normrnd(0.5,0.3);
% while F>1||F<0
%     F=normrnd(0.5,0.3);
% end
F = 0.6;
k = unifrnd (0 , 1);

switch DE_num
    case 1                                      %��һ�����ӣ��������������Ǿֲ�����ǿ
        x1 = randi([1 , length(population)]);
        x2 =  randi([1 , length(population)]);
        while x1==x2
            x2 =  randi([1 , length(population)]);
        end
        %ת����parent�������ռ�
        x_origin = [population((parent.skill_factor - 1) * length(population)/50 + 1:parent.skill_factor * length(population)/50).rnvec];
        x_origin = reshape(x_origin , [length(population)/50 ,  length(parent.rnvec)]);
        x_t1 = [population((population(x1).skill_factor - 1) * length(population)/50 + 1:population(x1).skill_factor * length(population)/50).rnvec];
        x_t1 = reshape(x_t1 , [length(population)/50 ,  length(parent.rnvec)]);
        
            [ x1_rnvec ] = domainAdation( x_origin , x_t1 ,population(x1));
%             [ population(x1).rnvec ] = prevent_cross_burder( population(x1).rnvec );
        
        x_t2 = [population((population(x2).skill_factor - 1) * length(population)/50 + 1:population(x2).skill_factor * length(population)/50).rnvec];
        x_t2 = reshape(x_t2 , [length(population)/50 ,  length(parent.rnvec)]);
       
            [ x2_rnvec ] = domainAdation( x_origin , x_t2 ,population(x2));
%             [ population(x2).rnvec ] = prevent_cross_burder( population(x2).rnvec );
            
        
        u = parent.rnvec + F.*(x1_rnvec-x2_rnvec);
    case 2                         %���н�ǿ��ȫ������
        
        x1 =  randi([1 , length(population)]);
        x2 =   randi([1 , length(population)]);
        while x1==x2
            x2 =  randi([1 , length(population)]);
        end
        x_origin = [population((parent.skill_factor - 1) * length(population)/50 + 1:parent.skill_factor * length(population)/50).rnvec];
        x_origin = reshape(x_origin , [length(population)/50 ,  length(parent.rnvec)]);
        x_t1 = [population((population(x1).skill_factor - 1) * length(population)/50 + 1:population(x1).skill_factor * length(population)/50).rnvec];
        x_t1 = reshape(x_t1 , [length(population)/50 ,  length(parent.rnvec)]);
      
            [x1_rnvec ] = domainAdation( x_origin , x_t1 ,population(x1));
%             [ population(x1).rnvec ] = prevent_cross_burder( population(x1).rnvec );
            
        
        x_t2 = [population((population(x2).skill_factor - 1) * length(population)/50 + 1:population(x2).skill_factor * length(population)/50).rnvec];
        x_t2 = reshape(x_t2 , [length(population)/50 ,  length(parent.rnvec)]);
     
            [ x2_rnvec ] = domainAdation( x_origin , x_t2 ,population(x2));
%             [ population(x2).rnvec ] = prevent_cross_burder( population(x2).rnvec );
            
        
        u = population((parent.skill_factor - 1) * length(population)/50 + 1).rnvec + F.*(x1_rnvec-x2_rnvec);
    case 3    %DE/current-to-rand
        x1 = randi([1 , length(population)]);
        x2 = randi([1 , length(population)]);
        while x1==x2
            x2 =  randi([1 , length(population)]);
        end
        
        x3 = randi([1 , length(population)]);
        while x1==x3 || x2 == x3
            x3 =  randi([1 , length(population)]);
        end
        
        u = parent.rnvec + k * (population(x1).rnvec - population(x2).rnvec) + k * F *(population(x2).rnvec - population(x3).rnvec);
        %         x1 = (parent.skill_factor - 1) * length(population)/50 + 1;
        %         x2 =  randi([1 , length(population)]);
        %         while x1==x2
        %             x2 =  randi([1 , length(population)]);
        %         end
        %         x3 =   randi([1 , length(population)]);
        %         while x1==x2 || x2==x3
        %             x3 =  randi([1 , length(population)]);
        %         end
        %         x4 =   randi([1 , length(population)]);
        %         while x1==x2 || x2==x3 ||x3==x4
        %             x4 =  randi([1 , length(population)]);
        %         end
        %
        %         x5 =   randi([1 , length(population)]);
        %         while x1==x2 || x2==x3 ||x3==x4||x4==x5
        %             x5 =  randi([1 , length(population)]);
        %         end
        %         x_origin = [population((parent.skill_factor - 1) * length(population)/50 + 1:parent.skill_factor * length(population)/50).rnvec];
        %         x_t2 = [population((population(x2).skill_factor - 1) * length(population)/50 + 1:population(x2).skill_factor * length(population)/50).rnvec];
        %         x_origin = reshape(x_origin , [length(population)/50 , length(parent.rnvec)]);
        %         x_t2 = reshape(x_t2 , [length(population)/50 ,  length(parent.rnvec)]);
        %         if rand(1) < 0.5
        %         [ population(x2).rnvec ] = domainAdation( x_origin , x_t2 ,population(x2));
        %         end
        %         x_t3 = [population((population(x3).skill_factor - 1) * length(population)/50 + 1:population(x3).skill_factor * length(population)/50).rnvec];
        %         x_t3 = reshape(x_t3 , [length(population)/50 ,  length(parent.rnvec)]);
        %         if rand(1) < 0.5
        %         [ population(x3).rnvec ] = domainAdation( x_origin , x_t3 ,population(x3));
        %         end
        %         x_t4 = [population((population(x4).skill_factor - 1) * length(population)/50 + 1:population(x4).skill_factor * length(population)/50).rnvec];
        %         x_t4 = reshape(x_t4 , [length(population)/50 ,  length(parent.rnvec)]);
        %         if rand(1) < 0.5
        %         [ population(x4).rnvec ] = domainAdation( x_origin , x_t4 ,population(x4));
        %         end
        %         x_t5 = [population((population(x5).skill_factor - 1) * length(population)/50 + 1:population(x5).skill_factor * length(population)/50).rnvec];
        %         x_t5 = reshape(x_t5 , [length(population)/50 ,  length(parent.rnvec)]);
        %         if rand(1) < 0.5
        %         [ population(x5).rnvec ] = domainAdation( x_origin , x_t5 ,population(x5));
end
j0=randi([1,length(u)]);   %��֤������һά�Ǵ�ԭ��������
[ u ] = prevent_cross_burder( u );
for i=1:length(u)
    if j0 ==i || rand(1)>cr		%��Ҫһάһά�Ĵ���
        u1(i) = parent.rnvec(i);
    else
        u1(i) = u(i);
    end
end
end

