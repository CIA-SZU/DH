%% DiffAdaptionDE: function description
%
function u1 = IdenAdaptionDE(parent , DE_num , population , gen)
% DE in identical task
cr = randi([3,9],1);
cr = cr/10;
% F=normrnd(0.5,0.3);
% while F>1||F<0
%     F=normrnd(0.5,0.3);
% end

k = unifrnd (0 , 1);
F = 0.2;
%ȷ��������1��������2
switch DE_num
    case 1                                      %��һ�����ӣ��������������Ǿֲ�����ǿ
        LowRange = (parent.skill_factor - 1) * 10 + 1;
        UpperRange = parent.skill_factor * 10;
        x1 =  randi([LowRange , UpperRange]);
        x2 =  randi([LowRange , UpperRange]);
        
        while x1==x2
            x2 =  randi([LowRange , UpperRange]);
        end
        u = parent.rnvec + F.*(population(x1).rnvec-population(x2).rnvec);
    case 2                         %���н�ǿ��ȫ������
        LowRange = (parent.skill_factor - 1) * 10 + 1;
        UpperRange = parent.skill_factor * 10;
        x1 =  randi([LowRange , UpperRange]);
        x2 =  randi([LowRange , UpperRange]);
        
        while x1==x2
            x2 =  randi([LowRange , UpperRange]);
        end
        
        u = population((parent.skill_factor - 1) * 10 + 1).rnvec + F.*(population(x1).rnvec-population(x2).rnvec);
    case 3
             x1 = randi([1 , length(population)]);
        x2 = randi([1 , length(population)]);
        while x1==x2
            x2 =  randi([1 , length(population)]);
        end
        
        x3 = randi([1 , length(population)]);
        while x1==x3 || x2 == x3
            x3 =  randi([1 , length(population)]);
        end
        
        u = parent.rnvec + k * (population(x1).rnvec - population(x2).rnvec) + k * F *(population(x2).rnvec - population(x3).rnvec);
%         LowRange = (parent.skill_factor - 1) * 10 + 1;
%         UpperRange = parent.skill_factor * 10;
%         x1 = (parent.skill_factor - 1) * 10 + 1;
%         x2 = randi([LowRange , UpperRange]);
%         while x1==x2
%             x2 =  randi([LowRange , UpperRange]);
%         end
%         x3 =  randi([LowRange , UpperRange]);
%         while x1==x2 || x2==x3
%             x3 =  randi([LowRange , UpperRange]);
%         end
%         x4 =  randi([LowRange , UpperRange]);
%         while x1==x2 || x2==x3 ||x3==x4
%             x4 =  randi([LowRange , UpperRange]);
%         end
%         
%         x5 =  randi([LowRange , UpperRange]);
%         while x1==x2 || x2==x3 ||x3==x4||x4==x5
%             x5 =  randi([LowRange , UpperRange]);
%         end
%         
%         u = parent.rnvec+ F.*(population(x1).rnvec-parent.rnvec) + F .* (population(x2).rnvec-population(x3).rnvec)+F.*(population(x4).rnvec-population(x5).rnvec);
end
j0=randi([1,length(u)]);   %��֤������һά�Ǵ�ԭ��������
[ u ] = prevent_cross_burder( u );
for i=1:length(u)
    if j0 ==i || rand(1)>cr		%��Ҫһάһά�Ĵ���
        u1(i) = parent.rnvec(i);
    else
        u1(i) = u(i);
    end
end
end

