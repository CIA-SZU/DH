x = [2013:1:2019]
plot(x , Untitled(1:end-1,1),'-*');
hold on
plot(x , Untitled(1:end-1,2),'-^');
plot(x , Untitled(1:end-1,3),'-+');
plot(x , Untitled(1:end-1,4),'-o');