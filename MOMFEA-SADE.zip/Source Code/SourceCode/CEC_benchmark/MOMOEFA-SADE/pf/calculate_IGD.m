function [value1,value2]=calculate_IGD( PF1,PF2, T1_data, T2_data )
%UNTITLED �˴���ʾ�йش˺�����ժҪ
%���ݲ�ͬ���������IGD��ֵ
%   �˴���ʾ��ϸ˵��
IGD = 0;
Distance = min(pdist2(PF1,T1_data),[],2);
sum1 = sum(Distance);
sum1=  sqrt(sum1);
IGD = sum1 / length(PF1);
% IGD = mean(Distance);

value1 = IGD;
IGD = 0;
% a = pdist2(PF2,T2_data);
Distance = min(pdist2(PF2,T2_data),[],2);
sum1 = sum(Distance);
sum1=  sqrt(sum1);
IGD = sum1 / length(PF2);

value2 = IGD;

%      IGD = sqrt(IGD)/1001;
% if strcmp(PF1 , 'convex')
%     load convex.pf
% %     for i = 1:1001
% %         c1 = convex(i,1)*ones(pop1,1);
% %         c2 = convex(i,2)*ones(pop1,1);
% %         IGD = IGD + ((sqrt(min(sum((T1_data-[c1 c2]).^2,2))))^2);
% %     end
% 
% Distance = min(pdist2(T1_data,convex),[],2);
% IGD = mean(Distance);
% %      IGD = sqrt(IGD)/1001;
% 
% %    
%     value1 = IGD;
%     
% elseif strcmp(PF1 , 'concave')
%     load concave.pf
% %     for i = 1:1000
% %         c1 = concave(i,1)*ones(pop1,1);
% %         c2 = concave(i,2)*ones(pop1,1);
% %         IGD = IGD + (min(sum((T1_data-[c1 c2]),2)));
% %     end
% %     IGD = sqrt(IGD)/1000;
% Distance = min(pdist2(T1_data,concave),[],2);
% IGD = mean(Distance);
%     value1 = IGD;
% elseif strcmp(PF1 , 'circle') %PF����Բ
%     load circle.pf
% %     for i = 1:1000
% %         c1 = circle(i,1)*ones(pop1,1);
% %         c2 = circle(i,2)*ones(pop1,1);
% %         IGD = IGD +(min(sum((T1_data-[c1 c2]),2)));
% %     end
% %     IGD = sqrt(IGD)/1000;
%             Distance = min(pdist2(circle,T1_data),[],2);
%             IGD = mean(Distance);
%     value1 = IGD;
% elseif strcmp(PF1,'ZDT3')  
%     load ZDT_3.mat
% %     ZDT_3 = ZDT3;
%                 Distance = min(pdist2(ZDT_3,T1_data),[],2);
%             IGD = mean(Distance);
%     value1 = IGD;
% else%��Ŀ������
%     load sphere1.pf
% %     for i = 1:10000   
% % 
% %         c1 =sphere1(i,1)*ones(pop1,1);
% %         c2 = sphere1(i,2)*ones(pop1,1);
% %         c3 = sphere1(i , 3) * ones(pop1,1);
% %         IGD = IGD + (min(sum((T1_data-[c1 c2 c3]),2)));
% %     end
% %     IGD = sqrt(IGD)/10000;
% Distance = min(pdist2(T1_data,sphere1),[],2);
% IGD = mean(Distance);
%     value1 = IGD;
%     
% end
% IGD = 0;
% if strcmp(PF2,'convex')
%     load convex.pf
% %     for i = 1:1001
% %         c1 = convex(i,1)*ones(pop2,1);
% %         c2 = convex(i,2)*ones(pop2,1);
% %         IGD = IGD + (min(sum((T2_data-[c1 c2]),2)));
% %     end
% %     IGD = sqrt(IGD)/1001;
% Distance = min(pdist2(T2_data,convex),[],2);
% IGD = mean(Distance);
%    value2=IGD;
% elseif strcmp(PF2,'concave')
%     load concave.pf
% %     for i = 1:1000
% %         c1 = concave(i,1)*ones(pop2,1);
% %         c2 = concave(i,2)*ones(pop2,1);
% %         IGD = IGD +(min(sum((T2_data-[c1 c2]),2)));
% %     end
% %      IGD = sqrt(IGD)/1000;
% Distance = min(pdist2(T2_data,concave),[],2);
% IGD = mean(Distance);
%     value2 = IGD;
% else%PF��Բ
%     load circle.pf
% %     for i = 1:1000
% %         c1 = circle(i,1)*ones(pop2,1);
% %         c2 = circle(i,2)*ones(pop2,1);
% %         IGD = IGD + (min(sum((T2_data-[c1 c2]),2)));
% % end
% %     IGD = sqrt(IGD)/1000;
% Distance = min(pdist2(T2_data,circle),[],2);
% IGD = mean(Distance);
%     value2 = IGD;
% end
% %  disp(['IGD1:' , num2str(value1)]);
%  disp(['IGD2:' , num2str(value2)]);
end

