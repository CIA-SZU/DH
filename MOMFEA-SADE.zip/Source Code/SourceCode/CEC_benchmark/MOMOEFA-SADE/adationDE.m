function [ u1 ] = adationDE( p  , DEnum ,population , parent )
%  p:ѡ����ĵ�һ�����      population ��ת�������Ⱥ �� parent ����ǰ����
    %�Ⱦ���mode
%     cr = randi([3,9],1);
    cr =0.5;
%     F=normrnd(0.5,0.3);
%     while F>1||F<0
%         F=normrnd(0.5,0.3);
%     end
F = 0.6;

        %ȷ��������1��������2
        switch DEnum
        case 1                                      %��һ�����ӣ��������������Ǿֲ�����ǿ
            x1 = randi([1 , length(population)]);
            x2 =  randi([1 , length(population)]);
            while x1==x2
                x2 =  randi([1 , length(population)]);
            end
            x3 =   randi([1 , length(population)]);
            while x1==x2 || x2==x3
                x3 =  randi([1 , length(population)]);
            end
            u = parent.rnvec + F.*(population(x2).rnvec-population(x3).rnvec);
        case 2                         %���н�ǿ��ȫ������
            x1 = 1;
            x2 =  randi([1 , length(population)]);
            while x1==x2
                x2 =  randi([1 , length(population)]);
            end
            x3 =   randi([1 , length(population)]);
            while x1==x2 || x2==x3
                x3 =  randi([1 , length(population)]);
            end
            u = parent.rnvec + F.*(population(x2).rnvec-population(x3).rnvec);
        case 3
            x1 = 1;
            x2 =  randi([1 , length(population)]);
            while x1==x2
                x2 =  randi([1 , length(population)]);
            end
            x3 =   randi([1 , length(population)]);
            while x1==x2 || x2==x3
                x3 =  randi([1 , length(population)]);
            end
              x4 =   randi([1 , length(population)]);
            while x1==x2 || x2==x3 ||x3==x4
                x4 =  randi([1 , length(population)]);
            end

            x5 =   randi([1 , length(population)]);
            while x1==x2 || x2==x3 ||x3==x4||x4==x5
                x5 =  randi([1 , length(population)]);
            end
            u = parent.rnvec+ F.*(population(x1).rnvec-p.rnvec)+F.*(population(x2).rnvec-population(x3).rnvec)+F.*(population(x4).rnvec-population(x5).rnvec);
        end
    %��������
    j0=randi([1,length(u)]);   %��֤������һά�Ǵ�ԭ��������
     [ u ] = prevent_cross_burder( u );
for i=1:length(u)
    if j0 ==i || rand(1)>cr		%��Ҫһάһά�Ĵ���
        u1(i) = u(i);
    else
        u1(i) = p.rnvec(i);
    end
end
                
                
end

