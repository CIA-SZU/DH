
function [store ,T1_f1 , T1_f2 , T2_f1,T2_f2,population]=MOMFEA_SADE(pop1,pop2,dim1 , dim2,rmp,gen,muc,mum,run,benchMark_num)
pop=pop1+pop2;
c1=0;
c2=0;

lp=30;
if mod(pop,2)~=0
    pop=pop+1;
    pop2=pop2+1;
end

dim=max([dim1,dim2]);
[F1 , F2] = loadPF(benchMark_num);
store=[];
dim = max(dim1 , dim2);
m1=[];
m2=[];
store=[];

for i=1:pop
    population(i)=Chromosome2;
    population(i)=initialize(population(i),dim);
    if i<=pop1
        population(i).skill_factor=1;
    else
        population(i).skill_factor=2;
    end
end

child1 = population([population.skill_factor]==1);
child2 = population([population.skill_factor]==2);
[child1 , child2] = evaluate(child1, child2 , benchMark_num);
population(1:pop1) = child1;
population(pop1 + 1:pop) = child2;

population_T1=population([population.skill_factor]==1);%�������ѧϰһ��
population_T2=population([population.skill_factor]==2);
no_of_objs_T1 = length(population_T1(1).objs_T1);
no_of_objs_T2 = length(population_T2(1).objs_T2);
[population_T1,frontnumbers]=SolutionComparison.nondominatedsort(population_T1,pop1,no_of_objs_T1);
[population_T1,~]=SolutionComparison.diversity(population_T1,frontnumbers,pop1,no_of_objs_T1);
[population_T2,frontnumbers]=SolutionComparison.nondominatedsort(population_T2,pop2,no_of_objs_T2);
[population_T2,~]=SolutionComparison.diversity(population_T2,frontnumbers,pop2,no_of_objs_T2);
population(1:pop1) = population_T1;
population(pop1+1:end) = population_T2;
pro_t1 = [1/3,1/3,1/3];
pro_t2 = [1/3,1/3,1/3];
pro_sum=[1/3,1/3,1/3];
SucMemTable_t2=[];
SucMemTable_t1=[];



strategy_count_t1=zeros(gen , 3);
strategy_count_t2=zeros(gen,3);
for generation=1:gen
    
    
    
    
    %  --------------------domain adation-------------------------
    for i=1:pop/2
        x_t1(i,:) = population(i).rnvec;
        x_t2(i,:) = population(i+pop/2).rnvec;
    end
    [coeff1,t1_pca,latent] = pca(x_t1,'NumComponents',dim*0.5);%coeff �е�ÿһ�б�ʾһ�����ɷ�
    
    [coeff2,t2_pca,latent] = pca(x_t2,'NumComponents',dim*0.5);%����ά�ȣ����Ǳ�����
    %pca ��ά  t1_pca:Ϊ��ά�������
    %һ�������Ӵ�����ID�ķ�����
    %
    
    orth_coeff1 = orth(coeff1);  %������
    orth_coeff2 = orth(coeff2);
    
    Xa = orth_coeff1*   orth_coeff1'*orth_coeff2;  %task1 ת��������2
    Xb = orth_coeff2*   orth_coeff2'*orth_coeff1;
    t1_pca = t1_pca*t1_pca'*t2_pca;
    t2_pca = t2_pca*t2_pca'*t1_pca;
    %     �ӿռ����
    %     Xa=coeff1*M1; %�ռ���룬�ṩһ�ִ�һ���ռ�ת������һ���ռ�ķ���,�����Xa���ɴ�task1ת����task2
    %     Xb=coeff2*M2;
    %     �����Ƚ�ά����ת���ռ䣬��ת����ȥ
    
    t1_pca_sa = x_t1*Xa;
    t2_pca_sa = x_t2*Xb;
    t1_pca_sa_re = t1_pca_sa*coeff2';
    t2_pca_sa_re = t2_pca_sa*coeff1';%�����ݻ�ԭ��ԭ��������
    % t1_pca_sa_re = t2_pca*coeff1';
    % t2_pca_sa_re = t1_pca*coeff2';
    %���ݻ�ԭ�������໥֮�以��
    t1_pca = myselfnom(t1_pca_sa_re);
    t2_pca = myselfnom(t2_pca_sa_re);
    %���¹�һ��
    %----------------------domain adation---------------------------
    %-------
    temppopulation_t1 = population;  %������2�ĸ���ȫ�����䵽����1
    temppopulation_t2 = population;     %������1�ĸ���ȫ�����䵽����2
    for i=1:pop/2
        temppopulation_t1(i+pop/2).rnvec = t2_pca(i,:);
        temppopulation_t1(i+pop/2).skill_factor=1;
        temppopulation_t2(i).rnvec = t1_pca(i,:);
        temppopulation_t2(i).skill_factor = 2;
    end
    
    adaption_population = [temppopulation_t1 , temppopulation_t2];
    T1_data = vec2mat([population(1:pop1).objs_T1],2);
    T2_data = vec2mat([population(pop1:pop).objs_T2],2);
    obj1 = T1_data(1:pop1,1);
    obj2 = T1_data(1:pop1,2);
    daobj1 = T2_data(1:pop2,1);
    daobj2 = T2_data(1:pop2,2);
    population_t1=population([population.skill_factor]==1);
    population_t2=population([population.skill_factor]==2);
    for i = 1:pop % Performing binary tournament selection to create parent pool
        parent(i)=Chromosome2();
        child(i)=Chromosome2;
        p1 = randi([1,pop],1);
        p2 = randi([1,pop],1);
        if population(p1).rank <= population(p2).rank
            parent(i).rnvec = population(p1).rnvec;
            parent(i).skill_factor = population(p1).skill_factor;
        else
            parent(i).rnvec = population(p2).rnvec;
            parent(i).skill_factor = population(p2).skill_factor;
        end
    end
    %������һ��������
    
    %     population = parent;
        rndlist=randperm(pop);
    parent=population(rndlist);%������˳��
    count=1;
           for i=1:pop % Create offspring population via mutation and crossover
        child(count)=Chromosome2;
        p1=i;
        if rand(1) < rmp
            DE_num = DEPOOL(pro_sum);
            [child(count).rnvec]= DiffAdaptionDE(parent(p1) ,DE_num ,adaption_population , generation); %����
            child(count).stra = DE_num;
            child(count).skill_factor=parent(p1).skill_factor;
            child(count).ischild = 1;
            strategy_count_t1(generation , DE_num) = strategy_count_t1(generation , DE_num)+1;
        else
            DE_num = DEPOOL(pro_sum);
            if parent(p1).skill_factor == 1
            [child(count).rnvec]= IdenAdaptionDE(parent(p1) ,DE_num ,temppopulation_t1 , generation); %����
            else
            [child(count).rnvec]= IdenAdaptionDE(parent(p1) ,DE_num ,temppopulation_t2 , generation); %����
            end
            
            child(count).stra = DE_num;
            child(count).skill_factor=parent(p1).skill_factor;
            child(count).ischild = 1;
            strategy_count_t1(generation , DE_num) = strategy_count_t1(generation , DE_num)+1;
        end
            count=count+1;
        end
    
    %������100�����Ӵ�
    child1 = child([child.skill_factor]==1);
     child2 = child([child.skill_factor]==2);
   
    [child1 , child2] = evaluate(child1, child2 , benchMark_num);
    child = [child1 , child2];
    
    population=reset(population,pop);%ÿ���һ�ν�����Ҫ���¼����֧������
    intpopulation(1:pop)=population;%ѧϰһ�£������ǿ���ֱ�Ӽӵ�
    intpopulation(pop+1:2*pop)=child;
    intpopulation_T1=intpopulation([intpopulation.skill_factor]==1);
    intpopulation_T2=intpopulation([intpopulation.skill_factor]==2);
    T1_pop=length(intpopulation_T1);
    T2_pop=length(intpopulation_T2);
    for i=1:T1_pop
        popobj1(i,:) = intpopulation_T1(i).objs_T1;
    end
    [ front1, FrontNO1,MaxFNO1] = NDSort(popobj1,inf);
    for i=1:T1_pop
        intpopulation_T1(i).front = FrontNO1(i);
    end
    %     ����2�ķ�֧������
    for i=1:T2_pop
        popobj2(i,:) = intpopulation_T2(i).objs_T2;
    end
    [ front2, FrontNO2,MaxFNO2] = NDSort(popobj2,inf);
    for i=1:T2_pop
        intpopulation_T2(i).front = FrontNO2(i);
    end
    [intpopulation_T1,~]=SolutionComparison.diversity(intpopulation_T1,front1,T1_pop,no_of_objs_T1);
    [intpopulation_T2,~]=SolutionComparison.diversity(intpopulation_T2,front2,T2_pop,no_of_objs_T2);
    %����������
    if generation > 800
    for c = 1:length(intpopulation_T1)
        Crowdis_t1(c) = intpopulation_T1(c).CD;
        Crowdis_t2(c) = intpopulation_T2(c).CD;
    end
    [a1 , a2] = sort(Crowdis_t1,'descend');
    intpopulation_T1 = intpopulation_T1(a2);
    [a1 , a2] = sort(Crowdis_t2,'descend');
    intpopulation_T2 = intpopulation_T2(a2);
    %
    end
    population(1:pop1) = intpopulation_T1(1:pop1);
    population(pop1+1:pop) = intpopulation_T2(1:pop2);
    %--------------------ͳ�ƴ����----------------------
    if generation>30
        [SucMemTable_t1,SucMemTable_t2]=survival_rate(population,child,generation ,lp ,SucMemTable_t1,SucMemTable_t2);
        
        [ pro_sum] = proComput(  strategy_count_t1,strategy_count_t2 ,SucMemTable_t1,SucMemTable_t2...
            ,generation);
        %--------------------ͳ�����--------------------------
    end
    if benchMark_num == 5
        T1_data = vec2mat([population(1:pop1).objs_T1],2);
        T2_data = vec2mat([population(pop1+1:pop).objs_T2],3);
    elseif benchMark_num == 9
        T1_data = vec2mat([population(1:pop1).objs_T1],3);
        T2_data = vec2mat([population(pop1+1:pop).objs_T2],2);
    else
        T1_data = vec2mat([population(1:pop1).objs_T1],2);
        T2_data = vec2mat([population(pop1+1:pop).objs_T2],2);
    end
    %         plot(T2_data(:,1) , T2_data(:,2),'o');
    %         pause(0.1);
    [value1 , value2] = calculate_IGD( F1,F2, T1_data, T2_data);
    %     %----------------------��ͬ������Ŀ��ռ�ֲ�ͼ---------------------
%     plot(F1(:,1) , F1(:,2),'.', 'DisplayName' , 'PF');
%     hold on
%     plot(T1_data(:,1) , T1_data(:,2) , 'o' , 'DisplayName' , 'Algorithm')
%     legend('show')
%     hold off
%     pause(0.001)
    %
    %     %-----------------------------------------------------------------------
    if generation>2
        a=min(store(1,:));
        b = min(store(2,:));
        if value1<a
            store(1,generation) = value1;
        else
            store(1,generation) =a;
        end
        if value2<b
            store(2,generation) = value2;
        else
            store(2,generation) =b;
        end
        
    else
        store(2,generation) = value2;
        store(1,generation) = value1;
    end
    
    
    for i=1:pop
        population(i).ischild=0;
        population(i).isparent=1;
    end
    
    
    
    
    
    disp(['DADE_with_newBenchmark_Generation:' , num2str(generation)]);
    disp(['current_task:' , num2str(benchMark_num)]);
    popobj1=[];
    popobj2=[];

end

T1_f1=[];
T1_f2=[];
T1_f3=[];
T2_f1=[];
T2_f2=[];
T2_f3=[];
for i=1:pop
    if population(i).skill_factor==1
        if no_of_objs_T1 == 2
            T1_f1=[T1_f1,population(i).objs_T1(1)];
            T1_f2=[T1_f2,population(i).objs_T1(2)];
        else
            T1_f1=[T1_f1,population(i).objs_T1(1)];
            T1_f2=[T1_f2,population(i).objs_T1(2)];
            T1_f3=[T1_f3,population(i).objs_T1(3)];
        end
    else
        if no_of_objs_T2 == 2
            T2_f1=[T2_f1,population(i).objs_T2(1)];
            T2_f2=[T2_f2,population(i).objs_T2(2)];
        else
            T2_f1=[T2_f1,population(i).objs_T2(1)];
            T2_f2=[T2_f2,population(i).objs_T2(2)];
            T2_f3=[T2_f3,population(i).objs_T2(3)];
        end
    end
end
end