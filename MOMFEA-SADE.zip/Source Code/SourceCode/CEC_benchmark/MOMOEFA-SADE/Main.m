
clear all
beep off
warning off
addpath(genpath(pwd));
gen = 1000;
global lp  %ѧϰ�Ĵ���
DADEIGD = {};

 CPLX_MODADE_task1 = zeros(10 , gen);
  CPLX_MODADE_task2 = zeros(10 , gen);
variance_task1 = zeros(10 , 20);
variance_task2 = zeros(10 , 20);
for run=1:1
for index = 1:1
[f1 ,f2,L1,U1,L2,U2,pop1,pop2,PF1,PF2 ] = Tasks(index);
pop1 = 100;
pop2 = 100;
rmp=0.9; % Random mating probability
 % Maximum Number of generations
muc = 20; % Distribution Index of SBX crossover operator
mum = 20; % Distribution Index of Polynomial Mutation operator
[dim1 , dim2] = getDim(index);
prob_vswap = 0; % Probability t/hat certain pair of variables are swapped (uniform crossover-like) during SBX crossover. Change to prob_swap = 0.5 for enhanced global search at the cost of high chromosome disruption.
[DADEIGD{run,index} , population] =  MOMFEA_SADE...  %ֻ������Ӧ��ֲ���
    (pop1,pop2,dim1 , dim2,rmp,gen,muc,mum,run,index);
end

end
for i=1:10
    for j = 1:run
    a =  DADEIGD{j,i};
  CPLX_MODADE_task1(i,:)  = a(1 , :) +  CPLX_MODADE_task1(i,:);
    
CPLX_MODADE_task2(i,:)  = a(2 , :) + CPLX_MODADE_task2(i,:) ;
    end
% variance_task1(i , run) =  a(1,end);
% variance_task2(i , run) =a(2,end);
end
 CPLX_MODADE_task1 =  CPLX_MODADE_task1 ./ run;
 CPLX_MODADE_task2 =  CPLX_MODADE_task2 ./ run;

%���㷽��
for i=1:10
    for j = 1:run
    a =  DADEIGD{j,i};
  CPLX_MODADE_task1_var(i,j)  = a(1 , end) ;    
CPLX_MODADE_task2_var(i,j)  = a(2 , end) ;
    end

end
variance1 = std(CPLX_MODADE_task1_var');
variance2 = std(CPLX_MODADE_task2_var');




save('CPLX_MODADE_task1' , 'CPLX_MODADE_task1');
save('CPLX_MODADE_task2' , 'CPLX_MODADE_task2');

% end
% t1 = t1./run; 
% t2 = t2./run;
% my_task1 = my_task1./run;
% my_task2 = my_task2./run;
% variance1 = (std(igd_t1'))';
% variance2 = (std(igd_t2'))';
% 
% save('my_task1','my_task1');
% save('my_task2','my_task2');

% load('mfeaigd_task2.mat');
% load('mfeaigd_task1.mat');

% plot_IGD(my_task1 , mfeaigd_task1,my_task2,mfeaigd_task2,9,500 );
% resultfun(MOMFEA_T1_f1,MOMFEA_T1_f2,MOMFEA_T2_f1,MOMFEA_T2_f2,MFEA_T1_f1,MFEA_T1_f2,MFEA_T2_f1,MFEA_T2_f2,7)