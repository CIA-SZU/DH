function [f1 ,f2,L1,U1,L2,U2,pop1,pop2,PF1,PF2 ] = Tasks( index)
%TASKS �˴���ʾ�йش˺�����ժҪ
%��������ļ���
%   �˴���ʾ��ϸ˵��
%�غϵĺ���
switch(index)
    case 1   %CIHS        ����֤û����
        PF1 = 'circle';
        PF2 = 'concave';
     
        f1 = 'CIHS_TASK1';
        f2 = 'CIHS_TASK2';
        L1=-100*ones(1,10);
        U1=100*ones(1,10);
        L1(1)=0;U1(1)=1;
        pop1=100; % Population size for task 1
        L2=-100*ones(1,10);
        U2=100*ones(1,10);
        L2(1)=0;U2(1)=1;
        pop2=100; % Population size for task 2
    case 2   %CIMS
        PF1 = 'concave';
        PF2 = 'circle';
        f1 = 'CIMS_TASK1';
        f2 = 'CIMS_TASK2';
        L1=-5*ones(1,10);
        U1=5*ones(1,10);
        L1(1)=0;U1(1)=1;
        pop1=100; % Population size for task 2
        L2=-5*ones(1,10);
        U2=5*ones(1,10);
        L2(1)=0;U2(1)=1;
        pop2=100; % Population size for task 2
    case 3  %CILS               ����֤û����
        PF1 = 'circle';
        PF2 = 'convex';
        f1 = 'CILS_TASK1';
        f2 = 'CILS_TASK2';
        L1=-2*ones(1,50);
        U1=2*ones(1,50);
        L1(1)=0;U1(1)=1;
        pop1=100; % Population size for task 1
        L2=-1*ones(1,50);
        U2=1*ones(1,50);
        L2(1)=0;U2(1)=1;
        pop2=100; % Population size for task 2
    case 4 %PIHS
        PF1 = 'convex';
        PF2 = 'convex';
        f1 = 'PIHS_TASK1';
        f2 = 'PIHS_TASK2';
        L1=-100*ones(1,50);
        U1=100*ones(1,50);
        L1(1)=0;U1(1)=1;
        pop1=100; % Population size for task 1
        L2=-100*ones(1,50);
        U2=100*ones(1,50);
        L2(1)=0;U2(1)=1;
        pop2=100; % Population size for task 2
    case 5 %PIMS  
        PF1 = 'circle';
        PF2 = 'concave';
        f1 = 'PIMS_TASK1';
        f2 = 'PIMS_TASK2';
        L1=0*ones(1,50);
        U1=1*ones(1,50);
        L1(1)=0;U1(1)=1;
        pop1=100; % Population size for task 1
        L2=0*ones(1,50);
        U2=1*ones(1,50);
        L2(1)=0;U2(1)=1;
        pop2=100; % Population size for task 2
    case 6 %PILS
        PF1 = 'circle';
        PF2 = 'circle';
        f1 = 'PILS_TASK1';
        f2 = 'PILS_TASK2';
        L1=-50*ones(1,50);
        U1=50*ones(1,50);
        L1(1)=0;U1(1)=1;
        pop1=100; % Population size for task 1
        L2=-100*ones(1,50);
        U2=100*ones(1,50);
        L2(1)=0;U2(1)=1;
        pop2=100; % Population size for task 2
    case 7 %NIHS
        PF1 = 'circle';
        PF2 = 'convex';
        f1 = 'NIHS_TASK1';
        f2 = 'NIHS_TASK2';
        L1=-80*ones(1,50);
        U1=80*ones(1,50);
        L1(1)=0;U1(1)=1;
        pop1=100; % Population size for task 1
        L2=-80*ones(1,50);
        U2=80*ones(1,50);
        L2(1)=0;U2(1)=1;
        pop2=100; % Population size for task 2
    case 8
         PF1 = 'sphere';
        PF2 = 'concave';
        f1 = 'NIMS_TASK1';
        f2 = 'NIMS_TASK2';
        L1=-20*ones(1,20);
        U1=20*ones(1,20);
        L1(1)=0;U1(1)=1;
        L1(2) = 0;U1(2)=1;
        pop1=100; % Population size for task 1
        L2=-20*ones(1,20);
        U2=20*ones(1,20);
        L2(1)=0;U2(1)=1;
        L2(2) = 0;U2(2) = 1;
        pop2=100; % Population size for task 2
         case 9
        PF1 = 'sphere';
        PF2 = 'concave';
        f1 = 'NILS_TASK1';
        f2 = 'NILS_TASK2';
        L1=-50*ones(1,25);
        U1=50*ones(1,25);
        L1(1)=0;U1(1)=1;
        L1(2) = 0;U1(2)=1;
        pop1=100; % Population size for task 1
        L2=-100*ones(1,50);
        U2=100*ones(1,50);
        L2(1)=0;U2(1)=1;
        L2(2) = 0;U2(2) = 1;
        pop2=100; % Population size for task 2
    case 10
        PF1 = 'ZDT3';
        PF2 = 'circle';
        f1 = 'ZCILS_TASK1';
        f2 = 'ZCILS_TASK2';
        L1 = 0*ones(1,30);
        U1 = 1*ones(1,30);
        pop1 = 100;
        L2 = -10*ones(1,30);
        U2 = 10*ones(1,30);
        L2(1)=0;
        U2(1)=1;
        pop2 = 100;
    case 11
        PF1 = 'ZDT3';
        PF2 = 'circle';
        f1 = 'ZPILS_TASK1';
        f2 = 'ZPILS_TASK2';
        L1 = 0*ones(1,30);
        U1 = 1*ones(1,30);
        pop1 = 100;
        L2 = 0*ones(1,30);
        U2 = 1*ones(1,30);
        pop2 = 100;
    case 12
         PF1 = 'ZDT3';
        PF2 = 'circle';
        f1 = 'ZNILS_TASK1';
        f2 = 'ZNILS_TASK2';
        L1 = 0*ones(1,50);
        U1 = 1*ones(1,50);
        pop1 = 100;
        L2 = 0*ones(1,50);
        U2 = 1*ones(1,50);
        pop2 = 100;       
        
end

