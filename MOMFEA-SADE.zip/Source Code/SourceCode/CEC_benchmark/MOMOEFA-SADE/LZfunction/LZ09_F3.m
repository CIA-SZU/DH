function [fitness] = LZ09_F3(numOfObjective , numOfVariable ,child)
	%input child:һ������
	ptype = 21;
	dtype = 1;
	ltype = 23;
	dim = numOfVariable;
	LZ09_F3 = LZ09(dim , numOfObjective , ltype , dtype , ptype);
	fitness = objectiveFunction(LZ09_F3 , child);

end