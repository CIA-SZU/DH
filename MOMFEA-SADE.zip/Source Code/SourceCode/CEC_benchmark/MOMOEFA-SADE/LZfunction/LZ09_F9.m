function [fitness] = LZ09_F9(numOfObjective , numOfVariable ,child)
	%input child:һ������
	ptype = 22;
	dtype = 1;
	ltype = 22;
	dim = numOfVariable;
	LZ09_F9 = LZ09(dim , numOfObjective , ltype , dtype , ptype);
	fitness = objectiveFunction(LZ09_F9 , child);

end