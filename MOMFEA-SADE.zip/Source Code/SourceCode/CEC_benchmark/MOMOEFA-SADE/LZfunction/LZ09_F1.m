function fitness = LZ09_F1( numOfObjective , numOfVariable , child )
	ptype = 21;
	dtype = 1;
	ltype = 21;
    
	dim = numOfVariable;
	lowerLimit = 0;
	upperLimit = 1;
	LZ09_F1 = LZ09(dim , numOfObjective , ltype , dtype , ptype);
	fitness=objectiveFunction(LZ09_F1 , child);
end

