This program mainly implements the MOMFEA-SADE which was described in our paper:

Evolutionary Multi-tasking for Multi-objective Optimization with Subspace Alignment and Adaptive DE


**************************************************************************************************************************************

1.The code was written in matlab.
2.Note that this trial version of the MOMFEA-SADE handles upto 2 "continuous" multi-objective multi-factorial optimization.
3.The test suite contain 10 multi-objective multi-factorial problems and can be download in http://www.bdsc.site/websites/MTO/index.html.	
4.Users can run the "MAIN.m" function to execute the algorithm.Note that some parameters can be tuned in "Main.m".

**************************************************************************************************************************************

Note that, this code can be used only for non-commercial purposes. 
We'd appreciate your acknowledgement if you use the code.  
For any problem concerning the code, please feel free to contact DongHao (email: 2172272106@email.szu.edu.cn).
